module.exports = (htmlStr, loan)=>{ // fat arrow function or lambda
    let output = htmlStr.replace(/{%NAME%}/g, loan.customerName);
    output = output.replace(/{%PHONE%}/g, loan.phoneNumber);
    output = output.replace(/{%ADDRESS%}/g, loan.address);
    output = output.replace(/{%INTEREST%}/g, loan.interest);
    output = output.replace(/{%LOANTERMYEARS%}/g, loan.loanTermYears);
    output = output.replace(/{%MONTHLYPAYMENT%}/g, loan.monthlyPayment);
    output = output.replace(/{%LOANTYPE%}/g, loan.loanType);

    const monthintr = (loan.interest * 0.01) / 12;
    const nomonths = (loan.loanTermYears * 12);
    const loanAmount = ((loan.monthlyPayment/monthintr)*(1-(Math.pow(1/(1+monthintr),nomonths))));

    output = output.replace(/{%LOANAMOUNT%}/g, loanAmount);
    output = output.replace(/{%DESCRIPTION%}/g, loan.description);
    output = output.replace(/{%ID%}/g, loan.id);
    return output;
}