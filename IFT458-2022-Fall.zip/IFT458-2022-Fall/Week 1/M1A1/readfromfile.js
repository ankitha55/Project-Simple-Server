let a = 10;
let b = 20;

c = a*b;

console.log(c);