let a = 10;
let b = 20;

let c = a * b;

console.log(c);
