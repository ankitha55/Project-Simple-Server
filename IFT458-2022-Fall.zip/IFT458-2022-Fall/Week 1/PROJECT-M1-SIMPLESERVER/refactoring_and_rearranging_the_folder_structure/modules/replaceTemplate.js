module.exports = (htmlstr, course)=>{
    let output = htmlstr.replace(/{%NAME%}/g, course.courseName);
     output = htmlstr.replace(/{%IMAGE%}/g, course.image);
     output = htmlstr.replace(/{%FROM%}/g, course.from);
     output = htmlstr.replace(/{%INSTRUCTOR%}/g, course.instructor);
     output = htmlstr.replace(/{%CREDITS%}/g, course.credits);
     output = htmlstr.replace(/{%DESCRIPTION%}/g, course.description);
     output = htmlstr.replace(/{%ID%}/g, course.id);
    return output;
}