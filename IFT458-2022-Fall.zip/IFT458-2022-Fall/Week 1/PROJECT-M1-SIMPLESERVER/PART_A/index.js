const httpServer = require('http');
const url = require('url');
////////////////////////////////
//create server
const server = httpServer.createServer(function (req, res){//call back function

    const urlParameter = url.parse(req.url, true);
    console.log(urlParameter.query);
    console.log(urlParameter.pathname);
    res.end(' We received our first request from the client')

});


//start listening to requests
server.listen(8000, 'localhost', function(){
    console.log(`listening to requests on port 8000`)
});